import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'weather_service.dart';

void main() {
  runApp(const ProviderScope(child: MyApp()));
}

final weatherServiceProvider = Provider((_) => WeatherService());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Météo',
      home: WeatherPage(),
    );
  }
}

class WeatherPage extends ConsumerWidget {
  const WeatherPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weatherService = ref.watch(weatherServiceProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Météo'),
      ),
      body: RefreshIndicator(
        onRefresh: () => weatherService.refreshWeatherData(),
        child: FutureBuilder(
          future: weatherService.fetchWeatherData(),
          builder: (context, AsyncSnapshot<Map<String, dynamic>> snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text('Erreur: ${snapshot.error}'));
            } else {
              final weatherData = snapshot.data!['data']['timelines'][0]['intervals'];
              return SingleChildScrollView(
                child: Column(
                  children: [
                    for (var index = 0; index < weatherData.length; index++)
                      Column(
                        children: [
                          ListTile(
                            title: Row(
                              children: [
                                const Icon(Icons.speed),
                                const SizedBox(width: 5),
                                const Text('Vitesse du vent: ', style: TextStyle(fontWeight: FontWeight.bold)),
                                Text('${weatherData[index]['values']['windSpeed']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                          ListTile(
                            title: Row(
                              children: [
                                const Icon(Icons.thermostat),
                                const SizedBox(width: 5),
                                const Text('Température: ', style: TextStyle(fontWeight: FontWeight.bold)),
                                Text('${weatherData[index]['values']['temperature']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                          ListTile(
                            title: Row(
                              children: [
                                const Icon(Icons.thermostat_outlined),
                                const SizedBox(width: 5),
                                const Text('Température apparent: ', style: TextStyle(fontWeight: FontWeight.bold)),
                                Text('${weatherData[index]['values']['temperatureApparent']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                              ],
                            ),
                          ),
                          const Divider(height: 12.1),
                        ],
                      ),
                  ],
                ),
              );
            }
          },
        ),
      ),
    );
  }
}
