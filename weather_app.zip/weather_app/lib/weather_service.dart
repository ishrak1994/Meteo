import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class WeatherService {
  Future<Map<String, dynamic>> fetchWeatherData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? cachedData = prefs.getString('weatherData');

    if (cachedData != null) {
      return json.decode(cachedData);
    } else {
      final response = await http.get(Uri.parse('http://10.0.2.2:3000/weather?timestep=1h'));
      if (response.statusCode == 200) {
        String data = response.body;
        prefs.setString('weatherData', data);
        return json.decode(data);
      } else {
        throw Exception('Failed to load weather');
      }
    }
  }

  Future<Map<String, dynamic>> refreshWeatherData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.remove('weatherData');
    await Future.delayed(const Duration(seconds: 1));
    return fetchWeatherData();
  }
}