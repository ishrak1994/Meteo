class Weather {
  final double windSpeed;
  final double temperature;
  final double apparentTemperature;

  Weather({
    required this.windSpeed,
    required this.temperature,
    required this.apparentTemperature,
  });

  factory Weather.fromJson(Map<String, dynamic> json) {
    return Weather(
      windSpeed: (json['windSpeed'] ?? 0).toDouble(),
      temperature: (json['temperature'] ?? 0).toDouble(),
      apparentTemperature: (json['temperatureApparent'] ?? 0).toDouble(),
    );
  }
}
