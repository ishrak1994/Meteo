import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:weather_app/main.dart';

void main() {
  testWidgets('Loading', (WidgetTester tester) async {

    await tester.pumpWidget(const MyApp());

    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    await tester.pump();

    expect(find.byType(CircularProgressIndicator), findsNothing);
  });

  testWidgets('Meteo data', (WidgetTester tester) async {

    await tester.pumpWidget(const MyApp());

    await tester.pumpAndSettle();

    expect(find.byType(ListTile), findsWidgets);

    expect(find.byIcon(Icons.speed), findsWidgets);
    expect(find.byIcon(Icons.thermostat), findsWidgets);
    expect(find.byIcon(Icons.thermostat_outlined), findsWidgets);

    expect(find.text('Vitesse du vent:'), findsWidgets);
    expect(find.text('Température:'), findsWidgets);
    expect(find.text('Température apparent:'), findsWidgets);
  });

}
